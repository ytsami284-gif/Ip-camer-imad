import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import '../models/camera_device.dart';

class CameraPlayer extends StatefulWidget {
  final CameraDevice camera;
  final bool compact;
  const CameraPlayer({super.key, required this.camera, this.compact = false});

  @override
  State<CameraPlayer> createState() => _CameraPlayerState();
}

class _CameraPlayerState extends State<CameraPlayer> {
  late final Player _player;
  late final VideoController _controller;
  String? _error;

  @override
  void initState() {
    super.initState();
    _player = Player();
    _controller = VideoController(_player);
    _open();
  }

  Future<void> _open() async {
    try {
      await _player.open(Media(widget.camera.streamUrl), play: true);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text('تعذر تشغيل البث\n$_error', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white)),
              ),
            )
          : Video(
              controller: _controller,
              controls: widget.compact ? NoVideoControls : MaterialVideoControls,
              fit: BoxFit.contain,
            ),
    );
  }
}
