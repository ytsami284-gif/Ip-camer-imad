import 'package:flutter/material.dart';
import '../models/camera_device.dart';
import '../services/camera_storage.dart';
import '../widgets/camera_player.dart';
import 'add_camera_screen.dart';
import 'view_camera_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _storage = CameraStorage();
  List<CameraDevice> _cameras = [];
  bool _grid = true;

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async { final c = await _storage.load(); if (mounted) setState(() => _cameras = c); }

  Future<void> _add() async {
    final c = await Navigator.push<CameraDevice>(context, MaterialPageRoute(builder: (_) => const AddCameraScreen()));
    if (c == null) return;
    setState(() => _cameras = [..._cameras, c]);
    await _storage.save(_cameras);
  }

  Future<void> _delete(CameraDevice c) async {
    setState(() => _cameras.removeWhere((x) => x.id == c.id));
    await _storage.save(_cameras);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('IMAD CAMERA'),
      actions: [IconButton(onPressed: () => setState(() => _grid = !_grid), icon: Icon(_grid ? Icons.view_list : Icons.grid_view))],
    ),
    body: _cameras.isEmpty
      ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.videocam_outlined, size: 80), const SizedBox(height: 12), const Text('لا توجد كاميرات بعد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('أضف كاميرا RTSP للبدء.'), const SizedBox(height: 20), FilledButton.icon(onPressed: _add, icon: const Icon(Icons.add), label: const Text('إضافة كاميرا'))]))
      : Padding(
          padding: const EdgeInsets.all(10),
          child: _grid ? GridView.builder(gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.45), itemCount: _cameras.length, itemBuilder: (_, i) => _tile(_cameras[i]))
          : ListView.separated(itemCount: _cameras.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) => SizedBox(height: 230, child: _tile(_cameras[i]))),
        ),
    floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('كاميرا')),
  );

  Widget _tile(CameraDevice c) => Card(clipBehavior: Clip.antiAlias, child: Stack(children: [
    Positioned.fill(child: InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ViewCameraScreen(camera: c))), child: CameraPlayer(camera: c, compact: true))),
    Positioned(left: 0, right: 0, bottom: 0, child: Container(color: Colors.black54, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), child: Row(children: [Expanded(child: Text(c.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)), PopupMenuButton<String>(color: Colors.white, onSelected: (v) { if (v == 'delete') _delete(c); }, itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف'))])]))),
  ]));
}
