import 'package:flutter/material.dart';
import '../models/camera_device.dart';
import 'qr_scan_screen.dart';

class AddCameraScreen extends StatefulWidget {
  const AddCameraScreen({super.key});
  @override
  State<AddCameraScreen> createState() => _AddCameraScreenState();
}

class _AddCameraScreenState extends State<AddCameraScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController(text: 'Camera 1');
  final _url = TextEditingController(text: 'rtsp://192.168.1.100:554/stream');
  final _username = TextEditingController();
  final _password = TextEditingController();

  @override
  void dispose() {
    _name.dispose(); _url.dispose(); _username.dispose(); _password.dispose(); super.dispose();
  }

  Future<void> _scanQr() async {
    final result = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const QrScanScreen()));
    if (!mounted || result == null) return;
    final uri = Uri.tryParse(result);
    if (uri != null && uri.scheme.toLowerCase() == 'rtsp') {
      _url.text = result;
      if (uri.userInfo.isNotEmpty) {
        final parts = uri.userInfo.split(':');
        _username.text = parts.first;
        if (parts.length > 1) _password.text = parts.sublist(1).join(':');
      }
      return;
    }
    // بعض الشركات تضع JSON أو نصًا خاصًا بها داخل QR. نعرض القيمة بدل افتراض أنها RTSP.
    _url.text = result;
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(context, CameraDevice(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: _name.text.trim(), url: _url.text.trim(),
      username: _username.text.trim(), password: _password.text,
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إضافة كاميرا')),
    body: Form(
      key: _formKey,
      child: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('RTSP', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('أدخل رابط بث RTSP. مثال: rtsp://192.168.1.100:554/stream'),
        const SizedBox(height: 16),
        FilledButton.tonalIcon(
          onPressed: _scanQr,
          icon: const Icon(Icons.qr_code_scanner),
          label: const Text('مسح QR Code تلقائيًا'),
        ),
        const SizedBox(height: 20),
        TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'اسم الكاميرا', border: OutlineInputBorder()), validator: (v) => v!.trim().isEmpty ? 'أدخل اسمًا' : null),
        const SizedBox(height: 14),
        TextFormField(controller: _url, decoration: const InputDecoration(labelText: 'RTSP URL', border: OutlineInputBorder()), keyboardType: TextInputType.url, validator: (v) => (v == null || !v.trim().startsWith('rtsp://')) ? 'يجب أن يبدأ الرابط بـ rtsp://' : null),
        const SizedBox(height: 14),
        TextFormField(controller: _username, decoration: const InputDecoration(labelText: 'اسم المستخدم (اختياري)', border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextFormField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور (اختياري)', border: OutlineInputBorder())),
        const SizedBox(height: 24),
        FilledButton.icon(onPressed: _save, icon: const Icon(Icons.add_a_photo), label: const Text('حفظ الكاميرا'), style: FilledButton.styleFrom(padding: const EdgeInsets.all(16))),
      ]),
    ),
  );
}
