import 'package:flutter/material.dart';
import '../models/camera_device.dart';
import '../widgets/camera_player.dart';

class ViewCameraScreen extends StatelessWidget {
  final CameraDevice camera;
  const ViewCameraScreen({super.key, required this.camera});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(camera.name)),
    body: Center(child: AspectRatio(aspectRatio: 16 / 9, child: CameraPlayer(camera: camera))),
  );
}
