import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/camera_device.dart';

class CameraStorage {
  static const _key = 'camera_devices_v1';

  Future<List<CameraDevice>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => CameraDevice.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> save(List<CameraDevice> cameras) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(cameras.map((e) => e.toJson()).toList()));
  }
}
