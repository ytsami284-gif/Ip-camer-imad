class CameraDevice {
  final String id;
  final String name;
  final String url;
  final String username;
  final String password;

  const CameraDevice({
    required this.id,
    required this.name,
    required this.url,
    this.username = '',
    this.password = '',
  });

  String get streamUrl {
    if (username.isEmpty) return url;
    final uri = Uri.tryParse(url);
    if (uri == null) return url;
    return uri.replace(userInfo: '$username:${Uri.encodeComponent(password)}').toString();
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'url': url,
        'username': username,
        'password': password,
      };

  factory CameraDevice.fromJson(Map<String, dynamic> json) => CameraDevice(
        id: json['id'] as String,
        name: json['name'] as String,
        url: json['url'] as String,
        username: (json['username'] as String?) ?? '',
        password: (json['password'] as String?) ?? '',
      );
}
