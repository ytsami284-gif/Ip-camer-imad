# IMAD CAMERA V2

Flutter starter app for a multi-brand IP camera viewer.

## New in V2
- QR Code scanner on the Add Camera screen.
- If the QR contains an `rtsp://...` URL, it is placed automatically in the RTSP field.
- If username/password are embedded in the RTSP URI, they are extracted into their fields.
- Other QR payloads are preserved for manual handling instead of being guessed.

## Run

```bash
flutter create .
flutter pub get
flutter run
```

For iOS, run on a real device or simulator with camera permission configured by the `mobile_scanner` plugin. On a real iPhone, allow camera access when prompted.

## Important
A QR code containing only a serial number, cloud device ID, or vendor-specific token does not automatically reveal an RTSP stream. Vendor APIs/SDKs or ONVIF discovery may be needed for those cameras.
