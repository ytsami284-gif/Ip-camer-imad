#!/usr/bin/env bash
set -euo pipefail
flutter create .
flutter pub get
flutter analyze
